package com.company;

public enum CarBody {

    SEDAN,
    PICKUP,
    LIMOUSINE,
    ROADSTER,
    HATCHBACK,
    KUPE
}
